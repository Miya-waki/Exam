import HeaderNavigation from "./HeaderNavigation";

export default function Notifications() {
  return (
    <>
      <HeaderNavigation />
      <h1>Notifaication Page</h1>
    </>
  );
}