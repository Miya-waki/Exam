import HeaderNavigation from "./HeaderNavigation";

export default function Messages() {
  return (
    <>
      <HeaderNavigation />
      <h1>Messages Page</h1>
    </>
  );
}