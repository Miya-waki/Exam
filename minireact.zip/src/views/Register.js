import { useState } from "react";
import { Link } from "react-router-dom";
import background from "./p1.jpg";
export default function Register() {

  const [email , setEmail] = useState("");
  const [username , setUsername] = useState("");
  const [password , setPassword] = useState("");
  const [address, setAddress] = useState("");
  const [mobile, setMobile] = useState("");

  function ValidateEmail(mail) 
  {
   if (/^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(mail))
    {
      return (true)
    }
      alert("You have entered an invalid email address!")
      return (false)
  }function phonenumber(inputtxt) {
    var phoneno = /^\(?([0-9]{3})\)?[-. ]?([0-9]{3})[-. ]?([0-9]{4})$/;
    if(inputtxt.match(phoneno)) {
      return true;
    }
    else {
      alert("please enter a valid mobile number");
      return false;
    }
  }
  
  return (
    <div className="container-fluid"
    style={{backgroundImage:`url(${background})`, backgroundRepeat: 'no-repeat',backgroundSize: 'cover',backgroundPosition:'cover'}}>
      <div
        className="row   align-items-center p-4"
        style={{ display:"flex",justifyContent:"center"  }}
      >
        <div className="  p-4 rounded "
        style={{width:"560px",opactiy:"80%", border:"1px solid grey"}}
           
  >

          <form>
            <div className="alert alert-dark h2">Registration Form</div>

            <div>
              <input
                className="form-control form-control-lg"
                type="text"
                placeholder="Enter username"
                onChange={(e)=>{
                  setUsername(e.target.value)
                   
                  }}
              />
            </div>

            <div className="mt-1">
              <input
                className="form-control form-control-lg"
                type="password"
                placeholder="Enter Password"
                onChange={(e)=>{
                  setPassword(e.target.value)
                   
                  }}
              />
            </div>

            <div className="mt-1">
              <input
                className="form-control form-control-lg"
                type="email"
                placeholder="Enter Email"

                onChange={(e)=>{
                setEmail(e.target.value)
                 
                }}
              />
            </div>

            <div className="mt-1">
              <input
                className="form-control form-control-lg"
                type="text"
                placeholder="Enter Mobile"
                onChange={(e)=>{
                  setMobile(e.target.value)
                   
                  }}
              />
            </div>

            <div className="mt-1">
              <input
                className="form-control form-control-lg"
                type="text"
                placeholder="Enter Address"
                 onChange={(e)=>{
                setAddress(e.target.value)
                 
                }}
              />
            </div>

            <div className="mt-1">
              <input
                type="button"
                value="Register"
                className="btn btn-dark w-100 btn-lg"
                onClick={()=>{
                  if(email === "" || username ===""|| password ===""|| mobile ===""||address===""){
                    alert("please fill all fields you have an empty field remaining")
                  }
                  if(email) ValidateEmail(email)
                  if(mobile) phonenumber(mobile)
                }}
              />
            </div>

            <div className="text-center">
              <Link to="/login" className="text-info">
                Login here..
              </Link>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}