import { imageExists } from "holderjs";
import { Link, useHref, useNavigate } from "react-router-dom";
import background from "./rf.jfif";
import { Container, Nav, Navbar } from "react-bootstrap";
import { useState } from "react";

export default function Login() {
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const user = sessionStorage.getItem("USER");
  const passw = sessionStorage.getItem("PASSWORD");
  console.log(user, passw, "hfcytgc");
  let navigate = useNavigate();
  const logout = () => navigate("/login");
  const navHome = () => user && passw && navigate("/welcome-home");
  const navExplore = () => navigate("/explore");
  const navMessage = () => user && passw && navigate("/messages");
  const navNotification = () => user && passw && navigate("/notification");

  const authenticate = () => {
    if (email === "" || password === "") {
      alert("You cannot leave  field empty!");
    } else if (
      email &&
      /^\w+([\.-]?\w+)*@\w+([\.-]?\w+)*(\.\w{2,3})+$/.test(email)
    ) {
      sessionStorage.setItem("USER", email);
      sessionStorage.setItem("PASSWORD", password);

      navigate("/welcome-home");
      return true;
    }
    alert("You have entered an invalid email address!");
    return false;
  };

  return (
    <div className="container-fluid ">
      <div className="row align-items-center ">
        <div className="col-4 col-md-6  p-8">
          <form>
            <div
              className="alert  align-text-centre  h2"
              style={{ color: "#fbda4d" }}
            >
              LOGIN
            </div>

            <div className="mb-2">
              <input
                type="text"
                className="form-control form-control-lg"
                placeholder="Enter Username"
                onChange={(e) => {
                  setEmail(e.target.value);
                }}
              />
            </div>

            <div className="mb-3">
              <input
                type="text"
                className="form-control form-control-lg"
                placeholder="Enter Password"
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
              />
            </div>

            <div>
              <input
                type="button"
                value="Login "
                className="btn btn-lg btn-outline-warning "
                onClick={authenticate}
              />
            </div>

            <div className="text-center mt-1">
              <Link to="/register" className="text-info ">
                Register Here...
              </Link>
            </div>
          </form>
        </div>

        <div className="col-6 col-md-6  p-4">
          <div className="row">
            <div className="col-12  ">
              <Navbar bg="white" variant="black" expand="lg" sticky="top">
                <Container fluid>
                  <Navbar.Toggle aria-controls="basic-navbar-nav " />
                  <Navbar.Collapse id="basic-navbar-nav">
                    <Nav className=" ">
                      <Nav.Link
                        style={{ paddingLeft: "2.5rem", fontSize: "x-large" }}
                        onClick={navHome}
                      >
                        Home
                      </Nav.Link>
                      <Nav.Link
                        style={{ paddingLeft: "2.5rem", fontSize: "x-large" }}
                        onClick={navExplore}
                      >
                        Explore
                      </Nav.Link>
                      <Nav.Link
                        style={{ paddingLeft: "2.5rem", fontSize: "x-large" }}
                        onClick={navMessage}
                      >
                        Messages
                      </Nav.Link>
                      <Nav.Link
                        style={{ paddingLeft: "2.5rem", fontSize: "x-large" }}
                        onClick={navNotification}
                      >
                        Notification
                      </Nav.Link>
                      <Nav.Link
                        style={{ paddingLeft: "2.5rem", fontSize: "x-large" }}
                        onClick={logout}
                      >
                        Logout
                      </Nav.Link>
                    </Nav>
                  </Navbar.Collapse>
                </Container>
              </Navbar>
            </div>
          </div>
          <div
            style={{
              backgroundImage: `url(${background})`,
              backgroundRepeat: "no-repeat",
              backgroundSize: "cover",
              backgroundPosition: "cover",
              height: "100vh",
            }}
          ></div>
        </div>
      </div>
    </div>
  );
}
